/*
 * motor.c
 *
 *  Created on: Oct 21, 2025
 *      Author: user4
 */

#include "motor.h"


void motor_up(){

};

void motor_dw(){

};

void motor_stop(){

};

void door_motor(){

};
