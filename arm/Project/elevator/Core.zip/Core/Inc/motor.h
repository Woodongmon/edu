/*
 * motor.h
 *
 *  Created on: Oct 21, 2025
 *      Author: user4
 */

#ifndef INC_MOTOR_H_
#define INC_MOTOR_H_

#include "Ap.h"

void motor_up();
void motor_dw();
void motor_stop();
void door_motor();



#endif /* INC_MOTOR_H_ */
